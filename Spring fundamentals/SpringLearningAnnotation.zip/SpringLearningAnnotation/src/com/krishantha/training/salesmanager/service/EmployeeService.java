package com.krishantha.training.salesmanager.service;

import com.krishantha.training.salesmanager.model.Employee;

import java.util.List;


public interface EmployeeService {
    List<Employee> getAllEmployees();
}

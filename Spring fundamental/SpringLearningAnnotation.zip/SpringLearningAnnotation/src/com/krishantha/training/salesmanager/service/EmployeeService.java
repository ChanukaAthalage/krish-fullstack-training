package com.krishantha.training.salesmanager.service;

import com.krishantha.training.salesmanager.model.Employee;

import java.util.List;

/**
 * Created by IntelliJ IDEA Ultimate.
 * User: Pasindu Raveen
 * Date: 23-Mar-22
 * Time: 10:14 AM
 * SpringLearning
 */
public interface EmployeeService {
    List<Employee> getAllEmployees();
}
